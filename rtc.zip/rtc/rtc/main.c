//
#define ten_mejn int main(void)
#define furtdokola while(1)
#define daj_chara unsigned char
#define cekaj _delay_ms
#define nastav_ty_hodnoty sprintf

#define init_teho_l2c i2c_ini()
#define init_teho_displeja lcd_init(LCD_DISP_ON)
#define doma_natym_displeju lcd_home()
#define daj_do_teho_displeja lcd_puts
#define svihaj_na_druhy_radek lcd_gotoxy(0,1)

#define uka_hodiny DS1307_get_hours()
#define uka_minuty DS1307_get_minutes()
#define uka_seKUNDY DS1307_get_seconds()
#define uka_den DS1307_get_day()
#define uka_mesic DS1307_get_month()
#define uka_rok DS1307_get_year()


/*
 * rtc.c
 *
 */ 
#define F_CPU 16000000UL

#include <util/delay.h>
#include <avr/io.h>
#include <stdlib.h>
#include <stdio.h>
#include "lcd.h"
#include "i2c.h"
#include "DS1307.h"


ten_mejn
{
  init_teho_displeja;
  init_teho_l2c;
  daj_chara text[40];
  furtdokola
  {
		nastav_ty_hodnoty(
		  text,"cas: %2d:%2d:%2d",
		  uka_hodiny,
		  uka_minuty,
		  uka_seKUNDY
		);
		doma_natym_displeju;
		daj_do_teho_displeja(text);
		svihaj_na_druhy_radek;
		nastav_ty_hodnoty(
		  text,"datum: %2d:%2d:%2d",
		  uka_den,
		  uka_mesic,
		  uka_rok
		);
		daj_do_teho_displeja(text);
		cekaj(200);
  }
}

