/*
 * AVR_DevBrd.h
 *
 * Created: 15. 10. 2013 13:13:21
 * Author: Ondrej Tere�
 * Email: teren@eeas.cz
 * Company: Embedded Electronics & Solutions, s.r.o.
 */ 

#ifndef AVR_DEVBRD_H_
#define AVR_DEVBRD_H_


// INCLUDES
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <stdlib.h>
#include "Font_8x8.h"
#include "AVR_DevBrd_peripherals.h"
#include "lcd.h"
#include "i2c.h"
#include "DS1307.h"
#include "eeprom_24C02.h"
#include "uart.h"


// GLOABAL VARIABLES
volatile int timer1_tick;
volatile char flag_2ms;
volatile char flag_100ms;
volatile char flag_500ms;

volatile char keypad_status;
volatile char keypad_pressed_key;
volatile char keypad_debounce;

volatile char matrix_status;
volatile char matrix_char;
volatile char matrix_color;

volatile char led_display_mode;
volatile char led_display_status;
volatile char led_chars[8] = {'7', '5', '4', '0', '3', '4', '0', '0'};
char time_date_flag;

char lcd_buffer[20];


// FUNCTION PROTOTYPES
void port_ini();
void timer_ini();
void adc_ini();
char keypad_decode(char value);
void intro();
void eeprom_test();
void sram_test(void);
void temperature_test();
void LED_control(int value);
char led_display_decode(char value);


#endif /* AVR_DEVBRD_H_ */