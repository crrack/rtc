/*
 * AVR_DevBrd_peripherals.h
 *
 * Created: 15. 10. 2013 15:04:19
 * Author: Ondrej Tere�
 * Email: teren@eeas.cz
 * Company: Embedded Electronics & Solutions, s.r.o.
 */ 


#ifndef AVR_DEVBRD_PERIPHERALS_H_
#define AVR_DEVBRD_PERIPHERALS_H_


// DEFINES
#define PORT_LED	PORTF
#define DDR_LED		DDRF
#define LED0		(1 << 0)
#define LED1		(1 << 1)
#define LED2		(1 << 2)
#define LED3		(1 << 3)
#define LED4		(1 << 4)
#define LED5		(1 << 5)
#define LED6		(1 << 6)
#define LED7		(1 << 7)

#define PIN_SW		PINK
#define DDR_SW		DDRK
#define SW0			(1 << 0)
#define SW1			(1 << 1)
#define SW2			(1 << 2)
#define SW3			(1 << 3)
#define SW4			(1 << 4)
#define SW5			(1 << 5)
#define SW6			(1 << 6)
#define SW7			(1 << 7)

#define PORT_PIEZO	PORTC
#define DDR_PIEZO	DDRC
#define PIEZO		(1 << 7)

#define PORT_LCD	PORTH
#define DDR_LCD		DDRH
#define LCD_D7		(1 << 7)
#define LCD_D6		(1 << 6)
#define LCD_D5		(1 << 5)
#define LCD_D4		(1 << 4)
#define LCD_E		(1 << 3)
#define LCD_RS		(1 << 2)
#define LCD_R1		0x80
#define LCD_R2		0xC0

#define PORT_USB	PORTH
#define DDR_USB		DDRH
#define USB_RX		(1 << 0)
#define USB_TX		(1 << 1)

#define PORT_KEYPAD	PORTE
#define DDR_KEYPAD	DDRE
#define PIN_KEYPAD	PINE
#define KEYPAD_R0	(1 << 0)
#define KEYPAD_R1	(1 << 1)
#define KEYPAD_R2	(1 << 2)
#define KEYPAD_R3	(1 << 3)
#define KEYPAD_C0	(1 << 4)
#define KEYPAD_C1	(1 << 5)
#define KEYPAD_C2	(1 << 6)
#define KEYPAD_C3	(1 << 7)

#define PORT_MATRIX_ROW		PORTL
#define DDR_MATRIX_ROW		DDRL

#define PORT_MATRIX_GREEN	PORTJ
#define DDR_MATRIX_GREEN	DDRJ

#define PORT_MATRIX_RED		PORTA
#define DDR_MATRIX_RED		DDRA

#define PORT_SEGMET_ANODES	PORTA
#define PORT_SEGMET_CATHODES	PORTJ


#endif /* AVR_DEVBRD_PERIPHERALS_H_ */